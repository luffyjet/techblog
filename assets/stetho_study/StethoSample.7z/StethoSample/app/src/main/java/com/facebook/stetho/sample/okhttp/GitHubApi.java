package com.facebook.stetho.sample.okhttp;

import com.facebook.stetho.okhttp.StethoInterceptor;
import com.squareup.okhttp.OkHttpClient;

import java.util.List;
import java.util.concurrent.TimeUnit;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.client.OkClient;
import retrofit.http.GET;
import retrofit.http.Path;

public class GitHubApi {
    private static final String BASE_URL = "https://api.github.com";
    static final int CONNECT_TIMEOUT_MILLIS = 15 * 1000; // 15s
    static final int READ_TIMEOUT_MILLIS = 20 * 1000; // 20s


    interface GitHub {
        //同步
        @GET("/repos/{owner}/{repo}/contributors")
        List<Contributor> contributors(@Path("owner") String owner, @Path("repo") String repo);

        //异步
        @GET("/repos/{owner}/{repo}/contributors")
        void contributors(@Path("owner") String owner, @Path("repo") String repo, Callback<List<Contributor>> callback);
    }


    /**
     * 用于Stethoscope调试的ttpClient
     */
    public static OkClient getOkClient() {
        OkHttpClient client = new OkHttpClient();
        client.setConnectTimeout(CONNECT_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS);
        client.setReadTimeout(READ_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS);
        client.networkInterceptors().add(new StethoInterceptor());
        return new OkClient(client);
    }


    public static void getContributors(Callback<List<Contributor>> callback) {
        RestAdapter restAdapter = new RestAdapter.Builder().setClient(getOkClient()).setEndpoint(BASE_URL).build();
        GitHub gitHub =  restAdapter.create(GitHub.class);
        gitHub.contributors("square", "retrofit", callback);
    }
}
