package com.facebook.stetho.sample;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.facebook.stetho.sample.httpurlcon.URLActivity;
import com.facebook.stetho.sample.okhttp.OkHttpActivity;

/**
 * title: 
 * author: luffyjet
 * since: 2015/4/6 17:45
 * project: StethoSample
 */
public class MainActivity extends ListActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ListView listView = getListView();
        listView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new String[]{"OkHttp", "HttpURLConnection"}));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        Intent ok = new Intent(MainActivity.this, OkHttpActivity.class);
                        startActivity(ok);
                        break;
                    case 1:
                        Intent url = new Intent(MainActivity.this, URLActivity.class);
                        startActivity(url);
                        break;
                }
            }
        });
    }
}
