package com.facebook.stetho.sample.okhttp;

/**
 * title: 
 * author: luffyjet
 * since: 2015/4/6 17:27
 * project: StethoSample
 */
public class Contributor {
    public  String login;
    public int contributions;
    @Override
    public String toString() {
        return login + ", " + contributions;
    }
}
