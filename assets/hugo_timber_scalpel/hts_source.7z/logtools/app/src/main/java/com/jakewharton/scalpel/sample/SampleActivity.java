package com.jakewharton.scalpel.sample;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import com.debugtools.R;
import com.jakewharton.scalpel.ScalpelFrameLayout;

import butterknife.ButterKnife;
import butterknife.InjectView;

import static android.widget.Toast.LENGTH_LONG;

public final class SampleActivity extends ActionBarActivity {
    private static boolean first = true;

    @InjectView(R.id.scalpel)
    ScalpelFrameLayout scalpelView;
    @InjectView(R.id.item_pager)
    ViewPager pagerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.sample_activity);
        ButterKnife.inject(this);

        pagerView.setAdapter(new SamplePagerAdapter(this));

        Switch enabledSwitch = new Switch(this);
        enabledSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (first) {
                    first = false;
                    Toast.makeText(SampleActivity.this, R.string.first_run, LENGTH_LONG).show();
                }

                scalpelView.setLayerInteractionEnabled(isChecked);
                invalidateOptionsMenu();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        actionBar.setCustomView(enabledSwitch);
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_TITLE | ActionBar.DISPLAY_SHOW_CUSTOM);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (!scalpelView.isLayerInteractionEnabled()) {
            return false;
        }
        menu.add("Draw Views")
                .setCheckable(true)
                .setChecked(scalpelView.isDrawingViews())
                .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        boolean checked = !item.isChecked();
                        item.setChecked(checked);
                        scalpelView.setDrawViews(checked);
                        return true;
                    }
                });
        menu.add("Draw IDs")
                .setCheckable(true)
                .setChecked(scalpelView.isDrawingIds())
                .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        boolean checked = !item.isChecked();
                        item.setChecked(checked);
                        scalpelView.setDrawIds(checked);
                        return true;
                    }
                });
        return true;
    }
}
