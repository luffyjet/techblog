package com.debugtools;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import timber.log.Timber;

import static android.widget.Toast.LENGTH_SHORT;

public class TimberActivity extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timber_demo_activity);
        findViewById(R.id.hello).setOnClickListener(onClickListener);
        findViewById(R.id.hey).setOnClickListener(onClickListener);
        findViewById(R.id.hi).setOnClickListener(onClickListener);

        Timber.tag("LifeCycles");
        Timber.d("Activity Created");
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Timber.i("A button with ID %s was clicked to say '%s'.", v.getId(), ((Button) v).getText());
            Toast.makeText(TimberActivity.this, "Check logcat for a greeting!", LENGTH_SHORT).show();
        }
    };
}
